<#
.SYNOPSIS
    Bulk employee onboarding: creates Active Directory accounts from a CSV
    and provisions a private home folder for each user.

.EXAMPLE
    .\New-BulkOnboarding.ps1 -CsvPath .\new_hires.csv -HomeRoot '\\FS01\Home' -WhatIf
    Dry run. Shows what would happen without changing anything.

.EXAMPLE
    .\New-BulkOnboarding.ps1 -CsvPath .\new_hires.csv -HomeRoot '\\FS01\Home'
    Real run. Prompts for the initial password.
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][ValidateScript({ Test-Path $_ })][string]$CsvPath,
    [Parameter(Mandatory)][string]$HomeRoot,
    [string]$DefaultOU   = 'OU=Staff,DC=contoso,DC=local',
    [string]$UpnSuffix   = 'contoso.local',
    [string]$LogPath     = ".\onboarding_log_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv",
    [SecureString]$InitialPassword
)

Import-Module ActiveDirectory -ErrorAction Stop

if (-not $InitialPassword) {
    $InitialPassword = Read-Host 'Enter initial password for new accounts' -AsSecureString
}

$required = 'FirstName','LastName','Department','Title'
$rows = Import-Csv -Path $CsvPath
$missing = $required | Where-Object { $_ -notin $rows[0].PSObject.Properties.Name }
if ($missing) { throw "CSV is missing required column(s): $($missing -join ', ')" }

$log = foreach ($row in $rows) {
    $sam    = ('{0}.{1}' -f $row.FirstName.Trim(), $row.LastName.Trim()).ToLower()
    $sam    = $sam.Substring(0, [Math]::Min($sam.Length, 20))   # sAMAccountName max 20 chars
    $name   = "$($row.FirstName.Trim()) $($row.LastName.Trim())"
    $ou     = if ($row.OU) { $row.OU } else { $DefaultOU }
    $folder = Join-Path $HomeRoot $sam
    $status = 'Success'; $detail = ''

    try {
        # 1. Skip duplicates
        if (Get-ADUser -Filter "SamAccountName -eq '$sam'" -ErrorAction SilentlyContinue) {
            $status = 'Skipped'; $detail = 'User already exists'
        }
        else {
            # 2. Create the AD account
            if ($PSCmdlet.ShouldProcess($sam, 'Create AD user')) {
                New-ADUser -Name $name -GivenName $row.FirstName -Surname $row.LastName `
                    -SamAccountName $sam -UserPrincipalName "$sam@$UpnSuffix" `
                    -Department $row.Department -Title $row.Title `
                    -Path $ou -AccountPassword $InitialPassword `
                    -Enabled $true -ChangePasswordAtLogon $true
            }

            # 3. Add to security groups (semicolon-separated in CSV)
            if ($row.Groups) {
                foreach ($g in ($row.Groups -split ';' | ForEach-Object { $_.Trim() } | Where-Object { $_ })) {
                    if ($PSCmdlet.ShouldProcess("$sam -> $g", 'Add to group')) {
                        Add-ADGroupMember -Identity $g -Members $sam
                    }
                }
            }

            # 4. Create home folder and grant the user Modify rights
            if ($PSCmdlet.ShouldProcess($folder, 'Create home folder + set ACL')) {
                New-Item -Path $folder -ItemType Directory -Force | Out-Null
                $acl  = Get-Acl $folder
                $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                    $sam, 'Modify', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
                $acl.AddAccessRule($rule)
                Set-Acl -Path $folder -AclObject $acl
            }
        }
    }
    catch {
        $status = 'Failed'; $detail = $_.Exception.Message
        Write-Warning "$sam : $detail"
    }

    [pscustomobject]@{
        Timestamp = Get-Date -Format 's'
        Username  = $sam
        Status    = $status
        Detail    = $detail
        HomeDir   = $folder
    }
}

$log | Export-Csv -Path $LogPath -NoTypeInformation
$log | Group-Object Status | Select-Object Name, Count | Format-Table -AutoSize
Write-Host "Log written to $LogPath"
