# AD Bulk Employee Onboarding (PowerShell)

Creates Active Directory user accounts from a CSV file, adds them to security
groups, and provisions a private home folder with correct NTFS permissions.
Every run produces a CSV audit log.

## Features
- CSV-driven: one row per new hire
- Duplicate detection (skips existing users)
- Group membership assignment
- Home folder creation with per-user Modify ACL
- `-WhatIf` dry-run support
- Per-user error handling (one bad row won't stop the batch)
- Timestamped CSV log

## Requirements
- Windows PowerShell 5.1+ or PowerShell 7 on a domain-joined machine
- RSAT: Active Directory module (`Install-WindowsFeature RSAT-AD-PowerShell` or Windows optional feature)
- Rights to create users and write to the file share

## Usage
```powershell
# 1. Dry run first
.\New-BulkOnboarding.ps1 -CsvPath .\new_hires.sample.csv -HomeRoot '\\FS01\Home' -WhatIf

# 2. Real run
.\New-BulkOnboarding.ps1 -CsvPath .\new_hires.sample.csv -HomeRoot '\\FS01\Home' `
    -DefaultOU 'OU=Staff,DC=contoso,DC=local' -UpnSuffix 'contoso.local'
```

## CSV format
| Column | Required | Notes |
|---|---|---|
| FirstName, LastName | Yes | Username becomes `first.last` |
| Department, Title | Yes | |
| OU | No | Overrides `-DefaultOU` |
| Groups | No | Semicolon-separated |

## Security notes
- Initial password is prompted as a SecureString and never written to disk or the log.
- Accounts are forced to change password at first logon.
- Only sample/fake data is included in this repo.

## Tested in
A lab domain (Windows Server 2022 DC, Windows 11 client). Add your own screenshots to `/screenshots`.
